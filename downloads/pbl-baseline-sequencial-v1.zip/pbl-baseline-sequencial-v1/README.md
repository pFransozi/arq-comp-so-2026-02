# Baseline sequencial — PBL de Arquitetura e Sistemas Operacionais

Este pacote é o **ponto de partida fornecido pelo professor**. Ele contém uma aplicação sequencial funcional, entradas reproduzíveis, testes, logs e métricas básicas. Na primeira aula, o objetivo é compreender e executar o programa — não reescrevê-lo.

## O que a aplicação faz

1. lê uma lista de tarefas de um arquivo JSON;
2. processa uma tarefa por vez;
3. conta números primos até o limite definido em cada tarefa;
4. grava os resultados em `outputs/`;
5. grava um log em `logs/`;
6. registra tempo total, tempo de CPU, pico de memória do processo e vazão.

A carga é CPU-bound, determinística e implementada em Python puro. Isso permite comparar futuramente a versão sequencial com versões usando threads e processos.

## Requisitos

- Python 3.10 ou superior;
- nenhuma biblioteca externa.

## Primeira execução

No terminal, entre na pasta do projeto e execute:

```bash
python main.py --entrada entradas/pequena.json
```

No Windows, caso `python` não esteja disponível:

```powershell
py main.py --entrada entradas/pequena.json
```

Depois, observe:

- `outputs/resultados_pequena.json`;
- `outputs/metricas_pequena.json`;
- `logs/execucao_pequena.log`;
- o resumo exibido no terminal.

## Testes

```bash
python -m unittest discover -s tests -v
```

## Entradas fornecidas

- `pequena.json`: reconhecimento inicial e execução rápida;
- `media.json`: medições intermediárias;
- `grande.json`: carga mais longa para experimentos posteriores.

Os tempos variam conforme o computador. Essa variabilidade deve ser registrada, não escondida.

## Métricas

O arquivo `outputs/metricas_<entrada>.json` contém:

- tempo total de parede;
- tempo de CPU do processo;
- pico de memória do processo (working set no Windows ou RSS máximo em sistemas Unix);
- tarefas concluídas e falhas;
- vazão em tarefas por segundo;
- informações básicas do ambiente.

> A forma de obtenção do pico de memória depende do sistema operacional. No Windows é usado o pico do working set; em sistemas Unix é usado o RSS máximo. A comparação deve registrar o ambiente e não misturar medições produzidas por métodos diferentes.

## Registro das medições

Use `medicoes/modelo_medicoes.csv` ou a tabela disponível no material da aula. Para comparações válidas, registre sempre a entrada, a versão, o número de workers e o ambiente.

## Evolução prevista

O baseline será preservado como referência. Ao longo do semestre, serão criadas versões com:

- threads;
- processos;
- fila de trabalho;
- estado compartilhado e condição de corrida controlada;
- sincronização;
- comparação de desempenho, correção e overhead.

Uma versão concorrente só será considerada melhor quando mantiver os resultados corretos e apresentar evidências reproduzíveis de ganho para a carga analisada.
