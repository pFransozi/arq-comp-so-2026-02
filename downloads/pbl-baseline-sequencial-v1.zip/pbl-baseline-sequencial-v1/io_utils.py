"""Leitura, validação e gravação dos artefatos do experimento."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any


def carregar_tarefas(caminho: Path) -> list[dict[str, Any]]:
    if not caminho.exists():
        raise FileNotFoundError(f"Arquivo de entrada não encontrado: {caminho}")
    try:
        dados = json.loads(caminho.read_text(encoding="utf-8"))
    except json.JSONDecodeError as erro:
        raise ValueError(f"JSON inválido em {caminho}: {erro}") from erro

    if not isinstance(dados, list):
        raise ValueError("O arquivo de entrada deve conter uma lista de tarefas.")
    if not dados:
        raise ValueError("O arquivo de entrada não pode estar vazio.")
    return dados


def gravar_json(caminho: Path, conteudo: Any) -> None:
    caminho.parent.mkdir(parents=True, exist_ok=True)
    caminho.write_text(
        json.dumps(conteudo, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def criar_logger(caminho: Path, verbose: bool = True) -> logging.Logger:
    caminho.parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("pbl_baseline")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    formato = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    arquivo = logging.FileHandler(caminho, mode="w", encoding="utf-8")
    arquivo.setFormatter(formato)
    logger.addHandler(arquivo)

    if verbose:
        terminal = logging.StreamHandler()
        terminal.setFormatter(formato)
        logger.addHandler(terminal)

    return logger
