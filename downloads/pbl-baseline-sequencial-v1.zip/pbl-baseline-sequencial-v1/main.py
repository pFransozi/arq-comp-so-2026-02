"""Ponto de entrada do baseline sequencial do PBL.

Exemplo:
    python main.py --entrada entradas/pequena.json
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

from io_utils import carregar_tarefas, criar_logger, gravar_json
from metricas import MedidorExecucao, informacoes_ambiente
from processador import processar_tarefa


def executar_baseline(
    entrada: Path,
    saida_resultados: Path,
    saida_metricas: Path,
    saida_log: Path,
    verbose: bool = True,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Executa as tarefas, uma por vez, preservando a ordem da entrada."""
    logger = criar_logger(saida_log, verbose=verbose)
    tarefas = carregar_tarefas(entrada)

    logger.info("Baseline sequencial iniciado")
    logger.info("Entrada: %s", entrada)
    logger.info("Tarefas recebidas: %d", len(tarefas))

    medidor = MedidorExecucao()
    medidor.iniciar()

    resultados: list[dict[str, Any]] = []
    falhas = 0

    for posicao, tarefa in enumerate(tarefas, start=1):
        identificador = tarefa.get("id", f"posicao-{posicao}") if isinstance(tarefa, dict) else f"posicao-{posicao}"
        logger.info("Tarefa %s iniciada (%d/%d)", identificador, posicao, len(tarefas))
        try:
            resultado = processar_tarefa(tarefa)
            resultados.append(resultado)
            logger.info(
                "Tarefa %s concluída em %.6f s",
                identificador,
                resultado["duracao_segundos"],
            )
        except (TypeError, ValueError) as erro:
            falhas += 1
            resultado_erro = {
                "id": identificador,
                "status": "falha",
                "erro": str(erro),
            }
            resultados.append(resultado_erro)
            logger.error("Tarefa %s falhou: %s", identificador, erro)

    medidas = medidor.finalizar()
    concluidas = len(tarefas) - falhas
    tempo_total = medidas["tempo_total_segundos"]
    vazao = concluidas / tempo_total if tempo_total > 0 else 0.0

    resumo = {
        "modo_execucao": "sequencial",
        "workers": 1,
        "arquivo_entrada": str(entrada),
        "arquivo_resultados": str(saida_resultados),
        "arquivo_log": str(saida_log),
        "tarefas_recebidas": len(tarefas),
        "tarefas_concluidas": concluidas,
        "falhas": falhas,
        **medidas,
        "vazao_tarefas_por_segundo": round(vazao, 3),
        "resultado_correto": falhas == 0,
        "ambiente": informacoes_ambiente(),
    }

    gravar_json(saida_resultados, resultados)
    gravar_json(saida_metricas, resumo)

    logger.info("Execução finalizada")
    logger.info("Tarefas concluídas: %d", concluidas)
    logger.info("Falhas: %d", falhas)
    logger.info("Tempo total: %.6f s", tempo_total)
    logger.info("Vazão: %.3f tarefas/s", vazao)
    logger.info("Resultados: %s", saida_resultados)
    logger.info("Métricas: %s", saida_metricas)

    return resultados, resumo


def construir_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Executa o baseline sequencial do PBL de Arquitetura e SO."
    )
    parser.add_argument(
        "--entrada",
        type=Path,
        default=Path("entradas/pequena.json"),
        help="Arquivo JSON com as tarefas (padrão: entradas/pequena.json).",
    )
    parser.add_argument("--resultados", type=Path, help="Caminho do JSON de resultados.")
    parser.add_argument("--metricas", type=Path, help="Caminho do JSON de métricas.")
    parser.add_argument("--log", type=Path, help="Caminho do arquivo de log.")
    parser.add_argument(
        "--silencioso",
        action="store_true",
        help="Não exibe os logs no terminal; mantém o arquivo de log.",
    )
    return parser


def main() -> int:
    parser = construir_parser()
    argumentos = parser.parse_args()

    nome = argumentos.entrada.stem
    saida_resultados = argumentos.resultados or Path("outputs") / f"resultados_{nome}.json"
    saida_metricas = argumentos.metricas or Path("outputs") / f"metricas_{nome}.json"
    saida_log = argumentos.log or Path("logs") / f"execucao_{nome}.log"

    try:
        _, resumo = executar_baseline(
            entrada=argumentos.entrada,
            saida_resultados=saida_resultados,
            saida_metricas=saida_metricas,
            saida_log=saida_log,
            verbose=not argumentos.silencioso,
        )
    except (FileNotFoundError, ValueError) as erro:
        parser.error(str(erro))

    print("\nResumo")
    print(f"  Tarefas recebidas: {resumo['tarefas_recebidas']}")
    print(f"  Tarefas concluídas: {resumo['tarefas_concluidas']}")
    print(f"  Falhas: {resumo['falhas']}")
    print(f"  Tempo total: {resumo['tempo_total_segundos']:.6f} s")
    print(f"  Tempo de CPU: {resumo['tempo_cpu_segundos']:.6f} s")
    print(f"  Pico de memória do processo: {resumo['pico_memoria_processo_mib']:.3f} MiB")
    print(f"  Vazão: {resumo['vazao_tarefas_por_segundo']:.3f} tarefas/s")
    print(f"  Resultados corretos: {'sim' if resumo['resultado_correto'] else 'não'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
