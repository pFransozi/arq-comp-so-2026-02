"""Funções de processamento do baseline sequencial.

O módulo contém uma carga CPU-bound simples, determinística e independente.
Ela foi escolhida para permitir medições e futura comparação entre execução
sequencial, multithread e multiprocesso.
"""

from __future__ import annotations

from time import perf_counter
from typing import Any


def contar_primos(limite: int) -> int:
    """Conta quantos números primos existem entre 2 e ``limite``.

    A implementação é propositalmente simples e escrita em Python puro para
    tornar o custo de CPU observável. Não é a forma mais eficiente de contar
    primos; isso faz parte das limitações conhecidas do baseline.
    """
    if not isinstance(limite, int):
        raise TypeError("O campo 'limite' deve ser um número inteiro.")
    if limite < 0:
        raise ValueError("O campo 'limite' não pode ser negativo.")
    if limite < 2:
        return 0

    quantidade = 1  # o número 2
    for candidato in range(3, limite + 1, 2):
        eh_primo = True
        divisor = 3
        while divisor * divisor <= candidato:
            if candidato % divisor == 0:
                eh_primo = False
                break
            divisor += 2
        if eh_primo:
            quantidade += 1
    return quantidade


def processar_tarefa(tarefa: dict[str, Any]) -> dict[str, Any]:
    """Processa uma tarefa e devolve um resultado serializável em JSON."""
    if not isinstance(tarefa, dict):
        raise TypeError("Cada tarefa deve ser representada por um objeto JSON.")

    identificador = tarefa.get("id")
    limite = tarefa.get("limite")

    if identificador is None:
        raise ValueError("A tarefa precisa possuir o campo 'id'.")
    if limite is None:
        raise ValueError(f"A tarefa {identificador!r} precisa possuir o campo 'limite'.")

    inicio = perf_counter()
    quantidade_primos = contar_primos(limite)
    duracao = perf_counter() - inicio

    return {
        "id": identificador,
        "limite": limite,
        "quantidade_primos": quantidade_primos,
        "duracao_segundos": round(duracao, 6),
        "status": "concluida",
    }
