from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from main import executar_baseline
from processador import contar_primos, processar_tarefa


class TestProcessador(unittest.TestCase):
    def test_contar_primos_conhecidos(self) -> None:
        self.assertEqual(contar_primos(1), 0)
        self.assertEqual(contar_primos(2), 1)
        self.assertEqual(contar_primos(10), 4)
        self.assertEqual(contar_primos(100), 25)

    def test_processar_tarefa_preserva_identificador(self) -> None:
        resultado = processar_tarefa({"id": "T-01", "limite": 10})
        self.assertEqual(resultado["id"], "T-01")
        self.assertEqual(resultado["quantidade_primos"], 4)
        self.assertEqual(resultado["status"], "concluida")

    def test_tarefa_sem_limite_falha(self) -> None:
        with self.assertRaises(ValueError):
            processar_tarefa({"id": "T-02"})

    def test_execucao_baseline_gera_artefatos(self) -> None:
        with tempfile.TemporaryDirectory() as pasta:
            raiz = Path(pasta)
            entrada = raiz / "tarefas.json"
            entrada.write_text('[{"id": 1, "limite": 10}]', encoding="utf-8")
            resultados, resumo = executar_baseline(
                entrada=entrada,
                saida_resultados=raiz / "resultados.json",
                saida_metricas=raiz / "metricas.json",
                saida_log=raiz / "execucao.log",
                verbose=False,
            )
            self.assertEqual(resultados[0]["quantidade_primos"], 4)
            self.assertEqual(resumo["tarefas_concluidas"], 1)
            self.assertTrue(resumo["resultado_correto"])
            self.assertTrue((raiz / "resultados.json").exists())
            self.assertTrue((raiz / "metricas.json").exists())
            self.assertTrue((raiz / "execucao.log").exists())


if __name__ == "__main__":
    unittest.main()
