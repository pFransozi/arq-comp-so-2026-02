"""Coleta de métricas usando apenas a biblioteca-padrão do Python."""

from __future__ import annotations

import ctypes
import os
import platform
import sys
from ctypes import wintypes
from dataclasses import dataclass
from time import perf_counter, process_time
from typing import Any


def _pico_memoria_windows_mib() -> float | None:
    """Obtém o pico do working set no Windows via WinAPI."""
    if os.name != "nt":
        return None

    class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
        _fields_ = [
            ("cb", wintypes.DWORD),
            ("PageFaultCount", wintypes.DWORD),
            ("PeakWorkingSetSize", ctypes.c_size_t),
            ("WorkingSetSize", ctypes.c_size_t),
            ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
            ("QuotaPagedPoolUsage", ctypes.c_size_t),
            ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
            ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
            ("PagefileUsage", ctypes.c_size_t),
            ("PeakPagefileUsage", ctypes.c_size_t),
        ]

    contadores = PROCESS_MEMORY_COUNTERS()
    contadores.cb = ctypes.sizeof(contadores)
    processo_atual = ctypes.windll.kernel32.GetCurrentProcess()
    sucesso = ctypes.windll.psapi.GetProcessMemoryInfo(
        processo_atual,
        ctypes.byref(contadores),
        contadores.cb,
    )
    if not sucesso:
        return None
    return contadores.PeakWorkingSetSize / (1024 * 1024)


def _pico_memoria_unix_mib() -> float | None:
    """Obtém o pico de RSS em sistemas Unix por meio de resource."""
    if os.name == "nt":
        return None
    try:
        import resource

        valor = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # macOS reporta bytes; Linux e a maioria dos Unix reportam KiB.
        if sys.platform == "darwin":
            return valor / (1024 * 1024)
        return valor / 1024
    except (ImportError, ValueError):
        return None


def pico_memoria_processo_mib() -> float | None:
    valor = _pico_memoria_windows_mib() if os.name == "nt" else _pico_memoria_unix_mib()
    return round(valor, 3) if valor is not None else None


@dataclass
class MedidorExecucao:
    """Mede tempo de parede, tempo de CPU e pico de memória do processo."""

    inicio_parede: float = 0.0
    inicio_cpu: float = 0.0

    def iniciar(self) -> None:
        self.inicio_parede = perf_counter()
        self.inicio_cpu = process_time()

    def finalizar(self) -> dict[str, float | None]:
        tempo_total = perf_counter() - self.inicio_parede
        tempo_cpu = process_time() - self.inicio_cpu
        return {
            "tempo_total_segundos": round(tempo_total, 6),
            "tempo_cpu_segundos": round(tempo_cpu, 6),
            "pico_memoria_processo_mib": pico_memoria_processo_mib(),
        }


def informacoes_ambiente() -> dict[str, Any]:
    """Retorna informações mínimas para tornar a execução identificável."""
    return {
        "python": sys.version.split()[0],
        "implementacao_python": platform.python_implementation(),
        "sistema_operacional": platform.platform(),
        "arquitetura": platform.machine() or "nao_identificada",
        "cpus_logicas": os.cpu_count(),
    }
